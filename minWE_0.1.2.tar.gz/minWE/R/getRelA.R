#' @title Array with Pairwise Relationships
#'
#' @description Generate an array indicating the relationship(s) between all
#'  pairs of individuals according to the pedigree.
#'
#' @param Ped  dataframe with columns id - dam - sire.
#' @param GenBack  number of generations back to consider; 1 returns
#'   parent-offspring and sibling relationships, 2 also returns grand-parental,
#'   avuncular and first cousins.
#' @param patmat  logical, distinguish between paternal versus maternal relative
#'   pairs? For avuncular pairs, the distinction is never made.
#' @param List logical, return a list instead of the default array
#'
#' @return a 3D array indicating if the pair has the specified relationship (1)
#' or not (0). The various relationship considered are in the 3rd dimension:
#'  \item{M}{}
#'  \item{P}{}
#'  \item{FS}{full siblings, including double 'other half sibs'}
#'  \item{MS}{}
#'  \item{PS}{}
#'  \item{XS}{other sibs: mother of A is father of B, or vv}
#' etc.
#'
#' @useDynLib minWE, .registration = TRUE
#'
#' @examples
#' Rel_list <- GetRelA(Ped = minWE::Ped_HSg5, List=TRUE)
#' head(Rel_list[['P']])
#'
#' @export

GetRelA <- function(Ped = NULL, GenBack = 1, patmat = TRUE, List = FALSE)
{
  if (is.null(Ped))  stop("Please provide Pedigree")

  PedN <- PedToNum(Ped, gID = Ped[, 1], DoDummies = "no")
  nInd <- nrow(PedN$PedPar)
  nRel <- ifelse(GenBack == 1, 8, 19)

  TMP <- .Fortran(getrelz,
                  nind = nInd,
                  pedrf = as.integer(PedN$PedPar),
                  nrel = as.integer(nRel),
                  relv = integer(nInd * nInd * nRel) )

  Rels <- c("S", "M", "P", "O", "FS", "MHS", "PHS", "XHS")  # XHS: 'cross'-half-sibs
  RelsB <- c("S", "MP", "O", "FS", "HS")  # patmat = FALSE
  if (GenBack == 2) {
    Rels <- c(Rels, "MGM", "MGF", "PGM", "PGF", "GO",
              "FA", "FN", "HA", "HN", "DFC1", "FC1")
    RelsB <- c(RelsB, "GP", "GO",
               "FA", "FN", "HA", "HN", "DFC1", "FC1")
  }

  if (List) {  # e.g. when very large pedigree --> relA object.size too large

    IDs <- Ped[,1]
    RelL <- list()
    for (r in seq_along(Rels)) {
      tmpM <- matrix(TMP$relv[((r-1)*nInd*nInd +1) : (r*nInd*nInd)], nInd, nInd)
      tmpW <- which(tmpM == 1, arr.ind=TRUE, useNames = FALSE)
      RelL[[Rels[r]]] <- cbind(ID1 = IDs[ tmpW[,1] ],
                               ID2 = IDs[ tmpW[,2] ])
    }
    rm(TMP, tmpM, tmpW)

    if (!patmat) {   # combine maternal & paternal relatives
      RelL[['MP']] <- rbind(RelL[['M']], RelL[['P']])
      RelL[['HS']] <- rbind(RelL[['MHS']], RelL[['PHS']], RelL[['XHS']])
      if (GenBack == 2) {
        RelL[['GP']] <- rbind(RelL[['MGM']], RelL[['MGF']], RelL[['PGM']], RelL[['PGF']])
      }
      RelL <- RelL[ RelsB ]
    }

    return( RelL )

  } else {

    RelA <- array(TMP$relv, dim = c(nInd, nInd, nRel),
                  dimnames = list(ID1 = Ped[,1], ID2 = Ped[,1], Rel = Rels) )


    if (!patmat) {   # combine maternal & paternal relatives
      RelA.B <- array(0, dim = c(nInd, nInd, length(RelsB)),
                      dimnames=list(Ped$id, Ped$id, RelsB))
      RelA.B[,,"MP"] <- RelA[,,"M"] | RelA[,,"P"]
      RelA.B[,,"HS"] <- RelA[,,"MHS"] | RelA[,,"PHS"] | RelA[,,"XHS"]
      if (GenBack == 2) {
        RelA.B[,,"GP"] <- RelA[,,"MGM"] | RelA[,,"MGF"] | RelA[,,"PGM"] | RelA[,,"PGF"]
      }
      for (r in RelsB) {
        if (r %in% c("MP", "HS", "GP"))  next
        RelA.B[,,r] <- RelA[,,r]
      }
      RelA <- RelA.B
    }

    return( RelA )
  }
}


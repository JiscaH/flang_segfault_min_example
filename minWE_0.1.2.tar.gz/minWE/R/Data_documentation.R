#' @name Ped_HSg5
#' @docType data
#' @title Example pedigree: 'HSg5'
#'
#' @description A pedigree with five non-overlapping generations and considerable
#' inbreeding. Each female mated with two random males and each male with three
#' random females, producing four full-sib offspring per mating. This is
#' \strong{Pedigree II} in the paper.
#'
#' @keywords datasets 
#' @usage data(Ped_HSg5)
#' @format A data frame with 1000 rows and 3 variables (id, dam, sire)
NULL


#===============================================================================
#' @name LH_HSg5
#' @docType data
#' @title Example life history file: 'HSg5'
#'
#' @description This is the life history file associated with
#'   \code{\link{Ped_HSg5}}, which is \strong{Pedigree II} in the paper.
#'
#' @keywords datasets sequoia
#' @usage data(LH_HSg5)
#' @format A data frame with 1000 rows and 3 variables:
#' \describe{
#' \item{ID}{Female IDs start with 'a', males with 'b'; the next 2 numbers give
#'   the generation number (00 -- 05), the last 3 numbers the individual ID
#'   number (runs continuously across all generations)}
#' \item{Sex}{1 = female, 2 = male}
#' \item{BirthYear}{from 2000 (generation 0, founders) to 2005} }
#'
NULL


#===============================================================================
#' @name SimGeno_example
#' @docType data
#' @title Example genotype file: 'HSg5'
#'
#' @description Simulated genotype data for cohorts 1+2 in Pedigree
#'   \code{\link{Ped_HSg5}}
#'
#' @keywords datasets sequoia
#' @usage data(SimGeno_example)
#' @format A genotype matrix with 214 rows (ids) and 200 columns (SNPs). Each
#'   SNP is coded as 0/1/2 copies of the reference allele, with -9 for missing
#'   values. Ids are stored as rownames.
NULL

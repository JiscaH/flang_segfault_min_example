#include <R.h>
#include <Rinternals.h>
#include <R_ext/RS.h>
#include <stdlib.h> // for NULL
#include <R_ext/Rdynload.h>
#include <R_ext/Visibility.h>


static R_NativePrimitiveArgType relzType[] = {
  INTSXP,  // nInd
  INTSXP,  // PedRF
  INTSXP,  // nRel
  INTSXP,  // RelV
};


extern void F77_NAME(getrelz)(int *nind, int *pedrf, int *nrel, int *relv);


static const R_FortranMethodDef FortranEntries[] = {
  {"getrelz", (DL_FUNC) &F77_NAME(getrelz), 4, relzType},
  {NULL, NULL, 0, NULL}
};


void attribute_visible R_init_minWE(DllInfo *info)  // attribute_visible -> error
{
  R_registerRoutines(info,
                     NULL,          // .C
                     NULL,          // .Call
                     FortranEntries, // .Fortran
                     NULL);         // .External
  R_useDynamicSymbols(info, FALSE);
	R_forceSymbols(info, TRUE);  //available from R 3.0.0
}
